import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium",
  {
    variants: {
      variant: {
        default: "border-gold/30 bg-gold-muted text-gold-light",
        outline: "border-surface-border text-ink-soft",
        low: "border-risk-low/40 bg-risk-low/10 text-risk-low",
        medium: "border-risk-medium/40 bg-risk-medium/10 text-risk-medium",
        high: "border-risk-high/40 bg-risk-high/10 text-risk-high",
      },
    },
    defaultVariants: { variant: "default" },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
