import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 190"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("h-8 w-8", className)}
      aria-hidden="true"
    >
      <path
        d="M45 60 L92 100 L82 122 L28 92 L45 60Z"
        fill="currentColor"
      />
      <path
        d="M155 60 L108 100 L118 122 L172 92 L155 60Z"
        fill="currentColor"
      />
      <path d="M100 62 L122 90 L100 118 L78 90 Z" fill="currentColor" />
      <path
        d="M100 178 L30 95 L62 100 L100 145 L138 100 L170 95 L100 178Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function Logo({
  className,
  wordmarkClassName,
  showWordmark = true,
}: {
  className?: string;
  wordmarkClassName?: string;
  showWordmark?: boolean;
}) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <LogoMark className="h-7 w-7 text-gold" />
      {showWordmark && (
        <span
          className={cn(
            "text-lg font-semibold tracking-tight text-foreground",
            wordmarkClassName
          )}
        >
          Uqoodi
          <span className="text-gold">.</span>
        </span>
      )}
    </div>
  );
}
