"use client";

import { useState, useRef, type KeyboardEvent } from "react";
import { useTranslations } from "next-intl";
import { ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { FileUpload } from "@/components/chat/file-upload";

export function ChatInput({
  onSend,
  onFile,
  disabled,
}: {
  onSend: (text: string) => void;
  onFile: (file: File) => void;
  disabled?: boolean;
}) {
  const t = useTranslations("chat");
  const [value, setValue] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  function submit() {
    const trimmed = value.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed);
    setValue("");
  }

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  }

  return (
    <div className="border-t border-surface-border p-4">
      <div className="flex items-end gap-2 rounded-xl border border-surface-border bg-surface-raised p-2 focus-within:border-gold/50">
        <FileUpload onFile={onFile} />
        <Textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={t("placeholder")}
          className="max-h-40 min-h-[44px] flex-1 border-none bg-transparent px-2 py-2.5 focus-visible:border-none"
          rows={1}
        />
        <Button
          type="button"
          size="icon"
          className="shrink-0 rounded-full"
          disabled={!value.trim() || disabled}
          onClick={submit}
          aria-label="Send"
        >
          <ArrowUp className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
