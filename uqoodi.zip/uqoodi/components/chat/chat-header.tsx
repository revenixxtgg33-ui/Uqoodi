"use client";

import { useTranslations } from "next-intl";
import { SquarePen } from "lucide-react";
import { LogoMark } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { LanguageSwitcher } from "@/components/layout/language-switcher";

export function ChatHeader({ onNewChat }: { onNewChat: () => void }) {
  const t = useTranslations("chat");

  return (
    <header className="flex items-center justify-between border-b border-surface-border px-5 py-4">
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-muted">
          <LogoMark className="h-[18px] w-[18px] text-gold" />
        </div>
        <div>
          <p className="text-sm font-semibold text-foreground">{t("title")}</p>
          <p className="text-xs text-ink-soft">{t("subtitle")}</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <LanguageSwitcher compact />
        <Button variant="outline" size="sm" onClick={onNewChat}>
          <SquarePen className="h-3.5 w-3.5" />
          {t("new_chat")}
        </Button>
      </div>
    </header>
  );
}
