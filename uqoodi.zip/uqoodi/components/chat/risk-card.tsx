import { AlertTriangle, ShieldCheck, ShieldAlert } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type RiskLevel = "low" | "medium" | "high";

export interface RiskItem {
  clause: string;
  note: string;
  level: RiskLevel;
}

const levelConfig: Record<
  RiskLevel,
  { icon: typeof ShieldCheck; labelKey: string; dot: string }
> = {
  low: { icon: ShieldCheck, labelKey: "risk_low", dot: "bg-risk-low" },
  medium: { icon: AlertTriangle, labelKey: "risk_medium", dot: "bg-risk-medium" },
  high: { icon: ShieldAlert, labelKey: "risk_high", dot: "bg-risk-high" },
};

export function RiskCard({ items, labels }: { items: RiskItem[]; labels: Record<string, string> }) {
  return (
    <Card className="mt-3 divide-y divide-surface-border overflow-hidden">
      {items.map((item, i) => {
        const cfg = levelConfig[item.level];
        const Icon = cfg.icon;
        return (
          <div key={i} className="flex items-start gap-3 p-4">
            <span className={cn("mt-1 h-2 w-2 shrink-0 rounded-full", cfg.dot)} />
            <div className="flex-1">
              <div className="mb-1 flex items-center justify-between gap-2">
                <span className="text-sm font-medium text-foreground">{item.clause}</span>
                <Badge variant={item.level} className="shrink-0">
                  <Icon className="h-3 w-3" />
                  {labels[cfg.labelKey]}
                </Badge>
              </div>
              <p className="text-sm text-ink-soft">{item.note}</p>
            </div>
          </div>
        );
      })}
    </Card>
  );
}
