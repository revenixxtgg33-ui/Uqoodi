"use client";

import { useState, useRef, useEffect } from "react";
import { useTranslations } from "next-intl";
import { FileText, ShieldCheck, Sparkles } from "lucide-react";
import { ChatHeader } from "@/components/chat/chat-header";
import { ChatInput } from "@/components/chat/chat-input";
import { ChatMessage, type ChatMessageData } from "@/components/chat/chat-message";

// NOTE: chat logic is a placeholder. Wire this up to app/api/chat/route.ts
// once the real AI backend is dropped in.
async function requestAssistantReply(text: string): Promise<ChatMessageData> {
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text }),
    });
    if (res.ok) return await res.json();
  } catch {
    // fall through to local placeholder below
  }

  return {
    id: crypto.randomUUID(),
    role: "assistant",
    content:
      "This is a placeholder response. Connect app/api/chat/route.ts to your AI backend to generate real drafts and risk analysis.",
    contractText:
      "SERVICE AGREEMENT (DRAFT)\n\nThis Agreement is made between [Party A] and [Party B] for the provision of marketing services...",
    riskItems: [
      { clause: "Termination clause", note: "30-day notice period is balanced for both parties.", level: "low" },
      { clause: "Liability cap", note: "Cap is set below market standard for this contract value.", level: "medium" },
      { clause: "Auto-renewal", note: "No opt-out window defined before renewal date.", level: "high" },
    ],
  };
}

export function ChatWindow() {
  const t = useTranslations("chat");
  const [messages, setMessages] = useState<ChatMessageData[]>([]);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  async function handleSend(text: string) {
    const userMsg: ChatMessageData = { id: crypto.randomUUID(), role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);
    const reply = await requestAssistantReply(text);
    setMessages((prev) => [...prev, reply]);
    setLoading(false);
  }

  function handleFile(file: File) {
    const userMsg: ChatMessageData = {
      id: crypto.randomUUID(),
      role: "user",
      content: "",
      fileName: file.name,
    };
    setMessages((prev) => [...prev, userMsg]);
  }

  function handleNewChat() {
    setMessages([]);
  }

  const suggestions = [t("suggestion_1"), t("suggestion_2"), t("suggestion_3")];

  return (
    <div className="mx-auto flex h-[calc(100vh-4rem)] w-full max-w-3xl flex-col border-x border-surface-border">
      <ChatHeader onNewChat={handleNewChat} />

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-6">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-gold-muted">
              <Sparkles className="h-6 w-6 text-gold" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">{t("empty_title")}</h2>
            <p className="mt-1.5 max-w-sm text-sm text-ink-soft">{t("empty_subtitle")}</p>

            <div className="mt-8 flex w-full max-w-md flex-col gap-2">
              {suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => handleSend(s)}
                  className="flex items-center gap-2.5 rounded-md border border-surface-border bg-surface px-4 py-3 text-start text-sm text-foreground/85 transition-colors hover:border-gold/40 hover:text-gold"
                >
                  <FileText className="h-4 w-4 shrink-0 text-gold/70" />
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-6">
            {messages.map((m) => (
              <ChatMessage key={m.id} message={m} />
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-sm text-ink-soft">
                <ShieldCheck className="h-4 w-4 animate-pulse text-gold" />
                <span className="animate-pulse">…</span>
              </div>
            )}
          </div>
        )}
      </div>

      <ChatInput onSend={handleSend} onFile={handleFile} disabled={loading} />
    </div>
  );
}
