import { useTranslations } from "next-intl";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { LogoMark } from "@/components/logo";
import { RiskCard, type RiskItem } from "@/components/chat/risk-card";
import { cn } from "@/lib/utils";

export interface ChatMessageData {
  id: string;
  role: "user" | "assistant";
  content: string;
  contractText?: string;
  riskItems?: RiskItem[];
  fileName?: string;
}

export function ChatMessage({ message }: { message: ChatMessageData }) {
  const t = useTranslations("chat");
  const isUser = message.role === "user";

  return (
    <div className={cn("flex gap-3", isUser && "flex-row-reverse")}>
      <Avatar className="mt-1 h-8 w-8 shrink-0">
        {isUser ? (
          <AvatarFallback>U</AvatarFallback>
        ) : (
          <AvatarFallback className="bg-gold-muted">
            <LogoMark className="h-4 w-4 text-gold" />
          </AvatarFallback>
        )}
      </Avatar>

      <div className={cn("flex max-w-[80%] flex-col gap-2", isUser && "items-end")}>
        {message.fileName && (
          <div className="rounded-md border border-surface-border bg-surface-raised px-3 py-2 text-xs text-ink-soft">
            📎 {message.fileName}
          </div>
        )}

        {message.content && (
          <div
            className={cn(
              "rounded-lg px-4 py-3 text-sm leading-relaxed",
              isUser
                ? "bg-gold-gradient text-ink"
                : "border border-surface-border bg-surface text-foreground/90"
            )}
          >
            {message.content}
          </div>
        )}

        {message.contractText && (
          <pre className="w-full whitespace-pre-wrap rounded-lg border border-surface-border bg-surface-raised p-4 font-sans text-sm leading-relaxed text-foreground/85">
            {message.contractText}
          </pre>
        )}

        {message.riskItems && message.riskItems.length > 0 && (
          <RiskCard
            items={message.riskItems}
            labels={{
              risk_low: t("risk_low"),
              risk_medium: t("risk_medium"),
              risk_high: t("risk_high"),
            }}
          />
        )}
      </div>
    </div>
  );
}
