"use client";

import { MessageSquare } from "lucide-react";
import { Link } from "@/lib/navigation";

export function FloatingChatButton() {
  return (
    <Link
      href="/chat"
      className="fixed bottom-6 end-6 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-gold-gradient text-ink shadow-[0_10px_40px_-10px_rgba(201,165,76,0.6)] transition-transform hover:scale-105"
      aria-label="Open chat"
    >
      <MessageSquare className="h-6 w-6" />
    </Link>
  );
}
