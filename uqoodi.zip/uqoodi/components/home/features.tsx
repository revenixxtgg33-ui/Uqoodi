"use client";

import { useTranslations } from "next-intl";
import {
  Languages,
  ShieldAlert,
  ScanText,
  History,
  Users,
  Lock,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const icons = [Languages, ShieldAlert, ScanText, History, Users, Lock];

export function Features() {
  const t = useTranslations("features");
  const items = t.raw("items") as { title: string; desc: string }[];

  return (
    <section id="features" className="py-24">
      <div className="container">
        <div className="mx-auto mb-14 max-w-xl text-center">
          <span className="text-xs font-medium uppercase tracking-widest text-gold">
            {t("eyebrow")}
          </span>
          <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            {t("title")}
          </h2>
        </div>

        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {items.map((item, i) => {
            const Icon = icons[i % icons.length];
            return (
              <Card
                key={item.title}
                className="group relative overflow-hidden p-7 transition-colors hover:border-gold/40"
              >
                <div className="mb-5 flex h-11 w-11 items-center justify-center rounded-md border border-gold/25 bg-gold-muted text-gold">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mb-2 text-base font-semibold text-foreground">{item.title}</h3>
                <p className="text-sm leading-relaxed text-ink-soft">{item.desc}</p>
                <div className="absolute inset-x-0 bottom-0 h-px scale-x-0 bg-gold-gradient transition-transform duration-300 group-hover:scale-x-100" />
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
