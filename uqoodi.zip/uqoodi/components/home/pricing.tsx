"use client";

import { useTranslations } from "next-intl";
import { Check } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Plan = {
  name: string;
  price: string;
  period?: string;
  desc: string;
  features: string[];
};

export function Pricing() {
  const t = useTranslations("pricing");
  const plans = t.raw("plans") as Plan[];

  return (
    <section id="pricing" className="py-24">
      <div className="container">
        <div className="mx-auto mb-14 max-w-xl text-center">
          <span className="text-xs font-medium uppercase tracking-widest text-gold">
            {t("eyebrow")}
          </span>
          <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            {t("title")}
          </h2>
          <p className="mt-3 text-sm text-ink-soft">{t("subtitle")}</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {plans.map((plan, i) => {
            const featured = i === 1;
            return (
              <Card
                key={plan.name}
                className={cn(
                  "relative flex flex-col p-8",
                  featured
                    ? "border-gold/50 bg-surface-raised shadow-[0_0_60px_-15px_rgba(201,165,76,0.35)]"
                    : ""
                )}
              >
                {featured && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold-gradient px-3 py-1 text-[11px] font-semibold text-ink">
                    {t("most_popular")}
                  </span>
                )}
                <h3 className="text-sm font-medium uppercase tracking-wide text-ink-soft">
                  {plan.name}
                </h3>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className="text-3xl font-semibold text-foreground">{plan.price}</span>
                  {plan.period && (
                    <span className="text-sm text-ink-soft">{plan.period}</span>
                  )}
                </div>
                <p className="mt-3 text-sm text-ink-soft">{plan.desc}</p>

                <ul className="mt-7 flex flex-1 flex-col gap-3">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm text-foreground/85">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
                      {f}
                    </li>
                  ))}
                </ul>

                <Button
                  className="mt-8"
                  variant={featured ? "default" : "outline"}
                >
                  {t("cta")}
                </Button>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
