"use client";

import { useTranslations } from "next-intl";
import { Quote } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

type Testimonial = { quote: string; name: string; role: string };

export function Testimonials() {
  const t = useTranslations("testimonials");
  const items = t.raw("items") as Testimonial[];

  return (
    <section className="py-24">
      <div className="container">
        <div className="mx-auto mb-14 max-w-xl text-center">
          <span className="text-xs font-medium uppercase tracking-widest text-gold">
            {t("eyebrow")}
          </span>
          <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            {t("title")}
          </h2>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          {items.map((item) => (
            <Card key={item.name} className="flex flex-col justify-between p-7">
              <Quote className="mb-4 h-6 w-6 text-gold/50" />
              <p className="text-sm leading-relaxed text-foreground/85">{item.quote}</p>
              <div className="mt-6 flex items-center gap-3">
                <Avatar className="h-9 w-9">
                  <AvatarFallback>{item.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium text-foreground">{item.name}</p>
                  <p className="text-xs text-ink-soft">{item.role}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
