"use client";

import { useTranslations } from "next-intl";
import { ArrowUpRight, MessageSquare } from "lucide-react";
import { Link } from "@/lib/navigation";
import { Button } from "@/components/ui/button";
import { LogoMark } from "@/components/logo";

export function Hero() {
  const t = useTranslations("hero");

  const stats = [
    { value: t("stat_1_value"), label: t("stat_1_label") },
    { value: t("stat_2_value"), label: t("stat_2_label") },
    { value: t("stat_3_value"), label: t("stat_3_label") },
  ];

  return (
    <section className="relative overflow-hidden pb-24 pt-20 md:pb-32 md:pt-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 flex justify-center">
        <div className="h-[560px] w-[560px] rounded-full bg-gold/10 blur-[140px]" />
      </div>

      <div className="container flex flex-col items-center text-center">
        <div className="mb-8 animate-fade-up">
          <LogoMark className="h-16 w-16 text-gold drop-shadow-[0_0_24px_rgba(201,165,76,0.35)] md:h-20 md:w-20" />
        </div>

        <span
          className="mb-5 animate-fade-up rounded-full border border-gold/25 bg-gold-muted px-4 py-1.5 text-xs font-medium tracking-wide text-gold-light"
          style={{ animationDelay: "80ms" }}
        >
          {t("eyebrow")}
        </span>

        <h1
          className="max-w-3xl animate-fade-up text-balance text-4xl font-semibold leading-[1.1] tracking-tight text-foreground md:text-6xl"
          style={{ animationDelay: "140ms" }}
        >
          {t("title")}
        </h1>

        <p
          className="mt-6 max-w-xl animate-fade-up text-balance text-base text-ink-soft md:text-lg"
          style={{ animationDelay: "220ms" }}
        >
          {t("subtitle")}
        </p>

        <div
          className="mt-9 flex animate-fade-up flex-col items-center gap-3 sm:flex-row"
          style={{ animationDelay: "300ms" }}
        >
          <Button size="lg" asChild>
            <Link href="/chat">
              {t("cta_primary")}
              <ArrowUpRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link href="/chat">
              <MessageSquare className="h-4 w-4" />
              {t("cta_secondary")}
            </Link>
          </Button>
        </div>

        <div
          className="mt-16 grid w-full max-w-2xl animate-fade-up grid-cols-3 gap-6 border-t border-surface-border pt-10"
          style={{ animationDelay: "380ms" }}
        >
          {stats.map((s) => (
            <div key={s.label} className="flex flex-col items-center gap-1">
              <span className="gold-text text-2xl font-semibold md:text-3xl">{s.value}</span>
              <span className="text-xs text-ink-soft md:text-sm">{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
