"use client";

import { useState } from "react";
import { Link } from "@/lib/navigation";
import { useTranslations } from "next-intl";
import { Menu, X } from "lucide-react";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { AuthModal } from "@/components/auth/auth-modal";

export function Navbar() {
  const t = useTranslations("nav");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");

  const links = [
    { href: "/#features", label: t("features") },
    { href: "/#pricing", label: t("pricing") },
    { href: "/chat", label: t("chat") },
    { href: "/about", label: t("about") },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-surface-border/60 bg-background/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm text-foreground/75 transition-colors hover:text-gold"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <LanguageSwitcher />
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setAuthMode("login");
              setAuthOpen(true);
            }}
          >
            {t("login")}
          </Button>
          <Button
            size="sm"
            onClick={() => {
              setAuthMode("signup");
              setAuthOpen(true);
            }}
          >
            {t("signup")}
          </Button>
        </div>

        <button
          className="text-foreground md:hidden"
          onClick={() => setMobileOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t border-surface-border bg-background px-6 py-5 md:hidden">
          <nav className="flex flex-col gap-4">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="text-sm text-foreground/80"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="mt-5 flex items-center justify-between">
            <LanguageSwitcher />
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={() => setAuthOpen(true)}>
                {t("login")}
              </Button>
              <Button size="sm" onClick={() => setAuthOpen(true)}>
                {t("signup")}
              </Button>
            </div>
          </div>
        </div>
      )}

      <AuthModal open={authOpen} onOpenChange={setAuthOpen} defaultMode={authMode} />
    </header>
  );
}
