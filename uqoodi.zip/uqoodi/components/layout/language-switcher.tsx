"use client";

import { usePathname, useRouter } from "next/navigation";
import { useLocale } from "next-intl";
import { Languages } from "lucide-react";
import { cn } from "@/lib/utils";

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const locale = useLocale();
  const router = useRouter();
  const pathname = usePathname();

  function switchTo(next: "en" | "ar") {
    if (next === locale) return;
    const segments = pathname.split("/");
    segments[1] = next;
    router.push(segments.join("/"));
  }

  return (
    <div
      className={cn(
        "flex items-center gap-1 rounded-full border border-surface-border bg-surface-raised p-1 text-xs font-medium",
        compact && "scale-90"
      )}
    >
      <Languages className="ms-2 h-3.5 w-3.5 text-ink-soft" />
      <button
        onClick={() => switchTo("en")}
        className={cn(
          "rounded-full px-2.5 py-1 transition-colors",
          locale === "en" ? "bg-gold-gradient text-ink" : "text-ink-soft hover:text-foreground"
        )}
      >
        EN
      </button>
      <button
        onClick={() => switchTo("ar")}
        className={cn(
          "rounded-full px-2.5 py-1 transition-colors",
          locale === "ar" ? "bg-gold-gradient text-ink" : "text-ink-soft hover:text-foreground"
        )}
      >
        عربي
      </button>
    </div>
  );
}
