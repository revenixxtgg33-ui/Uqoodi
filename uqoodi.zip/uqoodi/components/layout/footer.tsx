import { useTranslations } from "next-intl";
import { Link } from "@/lib/navigation";
import { Logo } from "@/components/logo";
import { Instagram, Linkedin, Twitter } from "lucide-react";

export function Footer() {
  const t = useTranslations("footer");
  const tNav = useTranslations("nav");

  const social = [
    { href: "https://instagram.com/uqoodi", icon: Instagram, label: "Instagram" },
    { href: "https://linkedin.com/company/uqoodi", icon: Linkedin, label: "LinkedIn" },
    { href: "https://x.com/uqoodi", icon: Twitter, label: "X" },
  ];

  return (
    <footer className="border-t border-surface-border/60">
      <div className="container grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div className="flex flex-col gap-4">
          <Logo />
          <p className="max-w-xs text-sm text-ink-soft">{t("tagline")}</p>
          <div className="mt-2 flex items-center gap-3">
            {social.map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noreferrer"
                aria-label={s.label}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-surface-border text-ink-soft transition-colors hover:border-gold/60 hover:text-gold"
              >
                <s.icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <FooterCol title={t("product")}>
          <Link href="/#features" className="text-sm text-ink-soft hover:text-gold">
            {tNav("features")}
          </Link>
          <Link href="/#pricing" className="text-sm text-ink-soft hover:text-gold">
            {tNav("pricing")}
          </Link>
          <Link href="/chat" className="text-sm text-ink-soft hover:text-gold">
            {tNav("chat")}
          </Link>
        </FooterCol>

        <FooterCol title={t("company")}>
          <Link href="/about" className="text-sm text-ink-soft hover:text-gold">
            {t("about")}
          </Link>
        </FooterCol>

        <FooterCol title={t("legal")}>
          <Link href="/terms" className="text-sm text-ink-soft hover:text-gold">
            {t("terms")}
          </Link>
          <Link href="/privacy" className="text-sm text-ink-soft hover:text-gold">
            {t("privacy")}
          </Link>
        </FooterCol>
      </div>

      <div className="hairline" />

      <div className="container flex flex-col items-center justify-between gap-2 py-6 text-xs text-ink-soft md:flex-row">
        <span>© {new Date().getFullYear()} Uqoodi. {t("rights")}</span>
        <span className="tracking-wide">عقودي</span>
      </div>
    </footer>
  );
}

function FooterCol({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-3">
      <span className="text-sm font-semibold text-foreground">{title}</span>
      <div className="flex flex-col gap-3">{children}</div>
    </div>
  );
}
