import { useTranslations } from "next-intl";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";

const sections = [
  {
    heading: "1. Information we collect",
    body: "We collect account information (name, email), documents you upload or generate, and usage data needed to operate and improve Uqoodi.",
  },
  {
    heading: "2. How we use your data",
    body: "Your contract content is used solely to provide drafting, analysis, and storage features. We do not sell your documents or use them to train models without explicit consent.",
  },
  {
    heading: "3. Data security",
    body: "Documents are encrypted at rest and in transit. Access is restricted through role-based permissions within your workspace.",
  },
  {
    heading: "4. Third-party services",
    body: "We use Supabase for authentication and storage, and may use Google or Facebook sign-in, which are governed by their own privacy policies.",
  },
  {
    heading: "5. Your rights",
    body: "You may request access, correction, or deletion of your personal data at any time by contacting our support team.",
  },
  {
    heading: "6. Contact",
    body: "For privacy questions, reach out via the contact details on our About page.",
  },
];

export default function PrivacyPage() {
  const t = useTranslations("privacy");

  return (
    <>
      <Navbar />
      <main className="container max-w-3xl py-20">
        <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">{t("title")}</h1>
        <p className="mt-2 text-sm text-ink-soft">{t("updated")}</p>

        <div className="mt-10 flex flex-col gap-8">
          {sections.map((s) => (
            <section key={s.heading}>
              <h2 className="mb-2 text-lg font-semibold text-foreground">{s.heading}</h2>
              <p className="text-sm leading-relaxed text-ink-soft">{s.body}</p>
            </section>
          ))}
        </div>
      </main>
      <Footer />
    </>
  );
}
