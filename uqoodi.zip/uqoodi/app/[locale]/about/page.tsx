import { useTranslations } from "next-intl";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { LogoMark } from "@/components/logo";

export default function AboutPage() {
  const t = useTranslations("about");

  return (
    <>
      <Navbar />
      <main className="container flex flex-col items-center py-24 text-center">
        <LogoMark className="mb-6 h-12 w-12 text-gold" />
        <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">{t("title")}</h1>
        <p className="mt-6 max-w-2xl text-base leading-relaxed text-ink-soft">{t("body")}</p>
      </main>
      <Footer />
    </>
  );
}
