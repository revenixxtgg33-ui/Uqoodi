import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Hero } from "@/components/home/hero";
import { Features } from "@/components/home/features";
import { Pricing } from "@/components/home/pricing";
import { Testimonials } from "@/components/home/testimonials";
import { FloatingChatButton } from "@/components/home/floating-chat-button";

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <div className="hairline" />
        <Features />
        <div className="hairline" />
        <Pricing />
        <div className="hairline" />
        <Testimonials />
      </main>
      <Footer />
      <FloatingChatButton />
    </>
  );
}
