import { useTranslations } from "next-intl";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";

const sections = [
  {
    heading: "1. Acceptance of terms",
    body: "By accessing or using Uqoodi, you agree to be bound by these Terms of Service and all applicable laws and regulations in your jurisdiction.",
  },
  {
    heading: "2. Use of the service",
    body: "Uqoodi provides AI-assisted contract drafting and analysis. Generated documents are drafts and do not constitute legal advice; you remain responsible for legal review before execution.",
  },
  {
    heading: "3. Accounts",
    body: "You are responsible for maintaining the confidentiality of your account credentials and for all activity under your account.",
  },
  {
    heading: "4. Content ownership",
    body: "You retain ownership of documents you upload or generate. Uqoodi does not claim ownership over your contract content.",
  },
  {
    heading: "5. Limitation of liability",
    body: "Uqoodi is provided on an as-is basis. We are not liable for losses arising from reliance on AI-generated drafts without independent legal review.",
  },
  {
    heading: "6. Changes to these terms",
    body: "We may update these terms from time to time. Continued use of the service after changes constitutes acceptance of the revised terms.",
  },
];

export default function TermsPage() {
  const t = useTranslations("terms");

  return (
    <>
      <Navbar />
      <main className="container max-w-3xl py-20">
        <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">{t("title")}</h1>
        <p className="mt-2 text-sm text-ink-soft">{t("updated")}</p>

        <div className="mt-10 flex flex-col gap-8">
          {sections.map((s) => (
            <section key={s.heading}>
              <h2 className="mb-2 text-lg font-semibold text-foreground">{s.heading}</h2>
              <p className="text-sm leading-relaxed text-ink-soft">{s.body}</p>
            </section>
          ))}
        </div>
      </main>
      <Footer />
    </>
  );
}
