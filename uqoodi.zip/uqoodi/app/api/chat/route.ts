import { NextResponse } from "next/server";

// PLACEHOLDER — intentionally not implemented.
// Replace this file with your existing api/chat.js logic (ported to a
// Next.js Route Handler). The frontend at components/chat/chat-window.tsx
// POSTs { message: string } here and expects a ChatMessageData-shaped
// JSON response back:
//
// {
//   id: string,
//   role: "assistant",
//   content: string,
//   contractText?: string,
//   riskItems?: { clause: string; note: string; level: "low"|"medium"|"high" }[]
// }

export async function POST(req: Request) {
  return NextResponse.json(
    { error: "Not implemented. Wire up your AI backend here." },
    { status: 501 }
  );
}
