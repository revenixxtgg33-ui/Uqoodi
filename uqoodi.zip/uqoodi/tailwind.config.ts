import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "1.5rem",
      screens: { "2xl": "1280px" },
    },
    extend: {
      colors: {
        background: "#0f0f0f",
        foreground: "#f5f5f3",
        surface: {
          DEFAULT: "#161616",
          raised: "#1c1c1c",
          border: "#2a2a2a",
        },
        gold: {
          DEFAULT: "#c9a54c",
          light: "#e2c579",
          dark: "#9c7f36",
          muted: "#c9a54c1a",
        },
        ink: {
          DEFAULT: "#0f0f0f",
          soft: "#8a8a86",
        },
        risk: {
          low: "#3fae6a",
          medium: "#c9a54c",
          high: "#c94f4f",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        arabic: ["var(--font-cairo)", "system-ui", "sans-serif"],
      },
      borderRadius: {
        lg: "0.75rem",
        md: "0.5rem",
        sm: "0.375rem",
      },
      backgroundImage: {
        "gold-gradient": "linear-gradient(135deg, #e2c579 0%, #c9a54c 50%, #9c7f36 100%)",
        "hairline-gold": "linear-gradient(90deg, transparent, #c9a54c66, transparent)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s ease-out both",
        shimmer: "shimmer 3s linear infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;
