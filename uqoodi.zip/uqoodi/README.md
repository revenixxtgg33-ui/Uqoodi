# Uqoodi (عقودي)

Premium Gulf business contracts SaaS frontend — Next.js 14 App Router, Tailwind CSS,
hand-built shadcn/ui-style components, next-intl (EN/AR with RTL), and Supabase Auth
scaffolding (Google + Facebook).

## Getting started

```bash
npm install
cp .env.local.example .env.local   # fill in Supabase keys
npm run dev
```

Visit `http://localhost:3000` — you'll be redirected to `/en` (or `/ar`).

## Structure

- `app/[locale]/` — all localized pages: home, `/chat`, `/about`, `/terms`, `/privacy`
- `app/api/chat/route.ts` — **placeholder only**. Drop your existing chat logic here;
  the frontend already POSTs `{ message }` and expects a `ChatMessageData`-shaped
  JSON response (see comment in the file).
- `components/ui/` — hand-built shadcn-style primitives (button, card, dialog, input, etc.)
- `components/home/` — hero, features, pricing, testimonials, floating chat button
- `components/chat/` — chat header, message list, risk cards, file upload, composer
- `components/auth/auth-modal.tsx` — login/signup modal wired to Supabase OAuth
  (Google, Facebook) + email/password
- `lib/supabase/` — browser/server/middleware Supabase clients (`@supabase/ssr`)
- `lib/navigation.ts` — locale-aware `Link`/`useRouter`/`usePathname` from next-intl
- `messages/en.json`, `messages/ar.json` — all UI copy, ready to extend

## Notes

- Supabase OAuth redirect assumes a route at `/auth/callback` — add that route
  handler when you wire up the backend.
- The chat window currently falls back to a local placeholder reply (with a demo
  risk-analysis card) if `POST /api/chat` isn't implemented yet, so the UI is
  fully explorable before backend integration.
- Social links in the footer point to `@uqoodi` on Instagram, LinkedIn, and X —
  update the URLs in `components/layout/footer.tsx` if handles differ.
